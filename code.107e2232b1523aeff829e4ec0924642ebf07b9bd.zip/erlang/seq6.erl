-module(seq6).

-export([c/1]).

c(N) when N >= 1 -> N.
