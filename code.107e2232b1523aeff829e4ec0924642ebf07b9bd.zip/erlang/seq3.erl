-module(seq3).

-export([b/1]).

b(_) -> 1.
