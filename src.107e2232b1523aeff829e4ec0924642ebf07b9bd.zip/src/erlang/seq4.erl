-module(seq4).

-export([c/1]).

% SNIP BEGIN seq-c
c(N) -> N.
% SNIP END
