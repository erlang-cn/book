% SNIP BEGIN hello-world
-module(hello).

-export([world/0]).

world() -> "Hello, world!".
% SNIP END
